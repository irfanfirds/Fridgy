import Foundation

// Simple JSON file persistence helper.
// Stores/loads any Codable type to a single file in the app's Documents directory.
actor JSONStore {
    private let url: URL
    private let encoder: JSONEncoder
    private let decoder: JSONDecoder

    // Pass a base filename like "fridgy_db" (".json" will be appended if missing).
    init(filename: String, directory: FileManager.SearchPathDirectory = .documentDirectory) {
        let dir = FileManager.default.urls(for: directory, in: .userDomainMask).first!
        let name = filename.hasSuffix(".json") ? filename : filename + ".json"
        self.url = dir.appendingPathComponent(name)

        let enc = JSONEncoder()
        enc.outputFormatting = [.prettyPrinted, .sortedKeys]
        enc.dateEncodingStrategy = .iso8601
        self.encoder = enc

        let dec = JSONDecoder()
        dec.dateDecodingStrategy = .iso8601
        self.decoder = dec
    }

    func load<T: Decodable>(_ type: T.Type) throws -> T {
        let fm = FileManager.default
        guard fm.fileExists(atPath: url.path) else {
            throw CocoaError(.fileNoSuchFile)
        }
        let data = try Data(contentsOf: url)
        return try decoder.decode(T.self, from: data)
    }

    func save<T: Encodable>(_ value: T) throws {
        let data = try encoder.encode(value)
        // Atomic write to avoid partial files
        try data.write(to: url, options: .atomic)
    }

    func deleteIfExists() throws {
        let fm = FileManager.default
        if fm.fileExists(atPath: url.path) {
            try fm.removeItem(at: url)
        }
    }
}
