import SwiftUI

@main
struct FridgyApp: App {
    var body: some Scene {
        WindowGroup {
            RootView()
        }
    }
}
#Preview {
    RootView()
}
