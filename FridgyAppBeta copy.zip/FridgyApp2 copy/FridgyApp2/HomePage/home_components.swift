import SwiftUI

// MARK: - Today Overview Card
struct TodayOverviewCard: View {
    var body: some View {
        let today = Date()
        let dayName = DateFormatter.localizedString(from: today, dateStyle: .full, timeStyle: .none).components(separatedBy: ",").first ?? "Today"
        let number = Calendar.current.component(.day, from: today)
        let monthName = DateFormatter().then { $0.dateFormat = "MMMM" }.string(from: today)

        HStack(spacing: 16) {
            VStack(alignment: .leading, spacing: 6) {
                Text("Today")
                    .font(.title3) // bigger than subheadline
                    .fontWeight(.semibold)
                    .foregroundColor(.appWhite.opacity(0.95))
                Text(dayName)
                    .font(.subheadline) // bigger than caption
                    .fontWeight(.medium)
                    .foregroundColor(.appWhite.opacity(0.8))
            }
            Spacer()
            VStack(alignment: .trailing, spacing: 0) {
                Text("\(number)")
                    .font(.system(size: 40, weight: .bold)) // keep prominent
                    .foregroundColor(.appWhite)
                Text(monthName.uppercased())
                    .font(.footnote) // slightly bigger than caption
                    .fontWeight(.semibold)
                    .foregroundColor(.appWhite.opacity(0.85))
            }
        }
        .padding(20)
        .background(
            LinearGradient(colors: [.appBrown, .appDarkBrown], startPoint: .topLeading, endPoint: .bottomTrailing)
        )
        .cornerRadius(20)
        .shadow(color: .appBrown.opacity(0.3), radius: 8, x: 0, y: 4)
    }
}

// MARK: - Modern Stats Card
struct ModernStatsCard: View {
    let title: String
    let count: Int
    let subtitle: String
    let color: Color
    let icon: String

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Image(systemName: icon)
                    .font(.title3)
                    .foregroundColor(color)
                Spacer()
                Text("\(count)")
                    .font(.title)
                    .fontWeight(.bold)
                    .foregroundColor(.appBlack)
            }
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.subheadline)
                    .fontWeight(.semibold)
                    .foregroundColor(.appBlack)
                Text(subtitle)
                    .font(.caption)
                    .foregroundColor(.appDarkBrown.opacity(0.7))
            }
        }
        .padding(16)
        .frame(height: 100)
        .background(Color.appWhite)
        .cornerRadius(16)
        .shadow(color: .black.opacity(0.05), radius: 8, x: 0, y: 4)
    }
}

// MARK: - Expiring Item Card (horizontal list)
struct ExpiringItemCard: View {
    let item: FridgeItem
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Image(systemName: item.category.icon)
                    .font(.caption)
                    .foregroundColor(item.category.color)
                    .frame(width: 20, height: 20)
                    .background(item.category.color.opacity(0.2))
                    .cornerRadius(6)
                Spacer()
                Text("\(item.daysUntilExpiry)d")
                    .font(.caption)
                    .fontWeight(.semibold)
                    .foregroundColor(.appRed)
            }
            Text(item.name)
                .font(.subheadline)
                .fontWeight(.medium)
                .foregroundColor(.appBlack)
                .lineLimit(2)
            Text(item.amount)
                .font(.caption)
                .foregroundColor(.appDarkBrown.opacity(0.7))
        }
        .padding(12)
        .frame(width: 140, height: 90)
        .background(Color.appWhite)
        .cornerRadius(12)
        .shadow(color: .black.opacity(0.05), radius: 4, x: 0, y: 2)
    }
}

// MARK: - Categories View (stacked rectangles)
struct CategoriesView: View {
    @EnvironmentObject var store: FridgeStore

    var body: some View {
        ScrollView(showsIndicators: false) {
            LazyVStack(spacing: 12) {
                ForEach(ItemCategory.allCases, id: \.self) { category in
                    NavigationLink(destination: CategoryItemsPage(category: category).environmentObject(store)) {
                        CategoryCard(category: category, count: store.itemsByCategory[category]?.count ?? 0)
                    }
                    .buttonStyle(PlainButtonStyle())
                }
            }
            .padding(.horizontal, 20)
            .padding(.top, 12)

            Spacer(minLength: 100)
        }
        .background(Color.appCream)
        .navigationBarTitleDisplayMode(.inline)
    }
}

// Helper Card (full-width rectangle like item/recipe cards)
struct CategoryCard: View {
    let category: ItemCategory
    let count: Int
    var body: some View {
        HStack(spacing: 12) {
            // Icon
            Image(systemName: category.icon)
                .font(.title3)
                .foregroundColor(.appWhite)
                .frame(width: 44, height: 44)
                .background(category.color)
                .cornerRadius(12)

            // Texts
            VStack(alignment: .leading, spacing: 4) {
                Text(category.rawValue)
                    .font(.subheadline)
                    .fontWeight(.semibold)
                    .foregroundColor(.appBlack)
                Text("\(count) items")
                    .font(.caption)
                    .foregroundColor(.appDarkBrown.opacity(0.7))
            }

            Spacer()

            Image(systemName: "chevron.right")
                .foregroundColor(.appDarkBrown.opacity(0.5))
        }
        .padding(16)
        .background(Color.appWhite)
        .cornerRadius(16)
        .shadow(color: .black.opacity(0.05), radius: 8, x: 0, y: 4)
    }
}

private extension DateFormatter {
    func then(_ apply: (DateFormatter) -> Void) -> DateFormatter { apply(self); return self }
}
