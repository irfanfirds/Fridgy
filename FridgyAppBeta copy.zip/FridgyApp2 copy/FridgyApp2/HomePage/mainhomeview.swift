import SwiftUI
import UIKit

struct RootView: View {
    @StateObject private var store = FridgeStore()
    @State private var selectedTab: Tab = .home
    @Environment(\.scenePhase) private var scenePhase
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    // Persist preferred display name; default “Fridgy”
    @AppStorage("userDisplayName") private var userName: String = "Fridgy"
    @State private var showNameEditor = false
    @State private var tempName = ""

    // Splash animation state
    @State private var showSplash = true
    @State private var doorAngle: Double = 0
    @State private var splashOpacity: Double = 1

    // About sheet
    @State private var showAbout = false

    // Fixed header height to keep tab bar from shifting across tabs
    private let headerHeight: CGFloat = 84

    var body: some View {
        NavigationStack {
            GeometryReader { geo in
                ZStack {
                    Color.appCream.ignoresSafeArea()

                    VStack(spacing: 10) {
                        // Shared header with consistent alignment and fixed height
                        HStack(alignment: .bottom) {
                            VStack(alignment: .leading, spacing: 4) {
                                if selectedTab == .home {
                                    Text(greetingText())
                                        .font(.subheadline)
                                        .foregroundColor(.appDarkBrown.opacity(0.8))
                                        .accessibilityLabel(greetingText().replacingOccurrences(of: "👋", with: ""))
                                    Text(userName)
                                        .font(.largeTitle)
                                        .fontWeight(.bold)
                                        .foregroundColor(.appBlack)
                                        .minimumScaleFactor(0.8)
                                        .accessibilityLabel("User name: \(userName)")
                                } else {
                                    Text(pageTitle(for: selectedTab))
                                        .font(.largeTitle)
                                        .fontWeight(.bold)
                                        .foregroundColor(.appBlack)
                                        .minimumScaleFactor(0.8)
                                        .accessibilityAddTraits(.isHeader)
                                }
                            }

                            Spacer()

                            // Align buttons with the page title baseline on Home
                            if selectedTab == .home {
                                HStack(spacing: 12) {
                                    // Small About button that shows the app icon and opens an "About" splash-style sheet
                                    Button {
                                        showAbout = true
                                    } label: {
                                        AppIconThumbnail() // already 30x30 inside
                                    }
                                    .accessibilityLabel("About the app")
                                    .accessibilityHint("Shows app information")

                                    Button {
                                        tempName = userName
                                        showNameEditor = true
                                        UIImpactFeedbackGenerator(style: .light).impactOccurred()
                                    } label: {
                                        Image(systemName: "person.circle.fill")
                                            .font(.system(size: 30, weight: .semibold))
                                            .foregroundColor(.appBrown)
                                    }
                                    .accessibilityLabel("Edit display name")
                                    .accessibilityHint("Opens a form to change your name")
                                }
                                .contentShape(Rectangle())
                            }
                        }
                        .padding(.horizontal, 20)
                        .padding(.top, 10)
                        .frame(height: headerHeight, alignment: .bottom)

                        // Custom tab bar now at a constant position under the fixed-height header
                        CustomTabBar(selectedTab: $selectedTab)
                            .frame(height: 60)

                        // Page content
                        Group {
                            switch selectedTab {
                            case .home:
                                HomeView(selectedTab: $selectedTab)
                            case .categories:
                                CategoriesView()
                            case .history:
                                HistoryView()
                            case .recipes:
                                RecipeListView()
                            case .add:
                                EmptyView()
                            }
                        }
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                    }
                }
            }
        }
        .fontDesign(.rounded)
        .environmentObject(store)
        .onAppear {
            NotificationManager.shared.requestPermission()
            startSplashAnimation()
        }
        .onChange(of: scenePhase) { _, newPhase in
            if newPhase == .background {
                Task { await store.flush() }
            }
        }
        .toolbar(.hidden, for: .navigationBar)
        // Name editor sheet
        .sheet(isPresented: $showNameEditor) {
            NavigationStack {
                Form {
                    Section("Display Name") {
                        TextField("Your name", text: $tempName)
                            .textInputAutocapitalization(.words)
                            .autocorrectionDisabled(true)
                            .accessibilityLabel("Display name")
                    }
                }
                .navigationTitle("Edit Name")
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) {
                        Button("Cancel") { showNameEditor = false }
                    }
                    ToolbarItem(placement: .confirmationAction) {
                        Button("Save") {
                            let trimmed = tempName.trimmingCharacters(in: .whitespacesAndNewlines)
                            userName = trimmed.isEmpty ? "Fridgy" : trimmed
                            UIImpactFeedbackGenerator(style: .light).impactOccurred()
                            showNameEditor = false
                        }
                        .accessibilityLabel("Save name")
                    }
                }
            }
        }
        // About sheet with splash-style presentation
        .sheet(isPresented: $showAbout) {
            AboutSheetView()
        }
        // Splash overlay
        .overlay {
            if showSplash {
                ZStack {
                    Color.appCream.ignoresSafeArea()
                    VStack(spacing: 20) {
                        FridgeLogoView(doorAngle: doorAngle)
                            .frame(width: 180, height: 240)
                            .accessibilityHidden(true)
                        Text("Fridgy")
                            .font(.title2.weight(.bold))
                            .foregroundColor(.appBlack)
                            .accessibilityAddTraits(.isHeader)
                    }
                }
                .opacity(splashOpacity)
                .transition(.opacity)
                .allowsHitTesting(true)
                .accessibilityLabel("Loading Fridgy")
            }
        }
    }

    private func startSplashAnimation() {
        guard showSplash else { return }
        if reduceMotion {
            splashOpacity = 0
            showSplash = false
            return
        }
        Task { @MainActor in
            try? await Task.sleep(nanoseconds: 300_000_000)
            withAnimation(.spring(response: 0.5, dampingFraction: 0.8, blendDuration: 0.2)) {
                doorAngle = 65
            }
            try? await Task.sleep(nanoseconds: 600_000_000)
            withAnimation(.spring(response: 0.45, dampingFraction: 0.9)) {
                doorAngle = 0
            }
            try? await Task.sleep(nanoseconds: 350_000_000)
            withAnimation(.easeOut(duration: 0.35)) {
                splashOpacity = 0
            }
            try? await Task.sleep(nanoseconds: 400_000_000)
            showSplash = false
        }
    }

    private func greetingText() -> String {
        let hour = Calendar.current.component(.hour, from: Date())
        switch hour {
        case 5..<12: return "Good Morning! 👋"
        case 12..<17: return "Good Afternoon! 👋"
        case 17..<22: return "Good Evening! 👋"
        default: return "Hello! 👋"
        }
    }

    private func pageTitle(for tab: Tab) -> String {
        switch tab {
        case .home: return "Home"
        case .categories: return "Items"
        case .history: return "History"
        case .recipes: return "Recipes"
        case .add: return ""
        }
    }
}

// Small square thumbnail that displays the current app icon
private struct AppIconThumbnail: View {
    var body: some View {
        Group {
            if let image = AppIconProvider.primaryAppIconImage(),
               image.size.width > 0, image.size.height > 0 {
                Image(uiImage: image)
                    .resizable()
                    .aspectRatio(contentMode: .fill)
            } else {
                Image(systemName: "app.fill")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .foregroundColor(.appBrown)
                    .padding(6)
                    .background(Color.appLightGray)
            }
        }
        .frame(width: 30, height: 30)
        .clipShape(RoundedRectangle(cornerRadius: 6, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 6, style: .continuous)
                .stroke(Color.black.opacity(0.08), lineWidth: 1)
        )
        .shadow(color: .black.opacity(0.08), radius: 2, x: 0, y: 1)
        .contentShape(RoundedRectangle(cornerRadius: 6, style: .continuous))
    }
}

// Simple "About" screen presented as a sheet that feels like a splash with info
private struct AboutSheetView: View {
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            ZStack {
                Color.appCream.ignoresSafeArea()
                VStack(spacing: 20) {
                    Group {
                        if let image = AppIconProvider.primaryAppIconImage() {
                            Image(uiImage: image)
                                .resizable()
                                .scaledToFit()
                        } else {
                            Image(systemName: "app.fill")
                                .resizable()
                                .scaledToFit()
                                .foregroundColor(.appBrown)
                                .padding(24)
                                .background(Color.appLightGray)
                        }
                    }
                    .frame(width: 140, height: 140)
                    .clipShape(RoundedRectangle(cornerRadius: 28, style: .continuous))
                    .shadow(color: .black.opacity(0.15), radius: 12, x: 0, y: 6)

                    Text(Bundle.main.appDisplayName)
                        .font(.title2.weight(.semibold))
                        .foregroundColor(.appBlack)

                    Text("Version \(Bundle.main.appVersion) (\(Bundle.main.appBuild))")
                        .font(.subheadline)
                        .foregroundColor(.appDarkBrown)

                    Text("Fridgy helps you track items in your fridge, avoid waste, and plan meals with ease.")
                        .font(.body)
                        .foregroundColor(.appDarkBrown)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 24)

                    Spacer()
                }
                .padding(.top, 40)
                .padding(.bottom, 20)
            }
            .navigationTitle("About")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") {
                        UIImpactFeedbackGenerator(style: .light).impactOccurred()
                        dismiss()
                    }
                    .accessibilityLabel("Close")
                }
            }
        }
    }
}

// Tries to fetch the primary app icon image from Info.plist CFBundleIcons
private enum AppIconProvider {
    static func primaryAppIconImage() -> UIImage? {
        #if canImport(UIKit)
        guard
            let info = Bundle.main.infoDictionary,
            let icons = info["CFBundleIcons"] as? [String: Any],
            let primary = icons["CFBundlePrimaryIcon"] as? [String: Any],
            let files = primary["CFBundleIconFiles"] as? [String],
            let iconName = files.last
        else { return nil }
        return UIImage(named: iconName)
        #else
        return nil
        #endif
    }
}

private extension Bundle {
    var appDisplayName: String {
        if let name = object(forInfoDictionaryKey: "CFBundleDisplayName") as? String {
            return name
        }
        return object(forInfoDictionaryKey: "CFBundleName") as? String ?? "App"
    }

    var appVersion: String {
        object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "1.0"
    }

    var appBuild: String {
        object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "1"
    }
}

// Simple fridge logo with an animating door
private struct FridgeLogoView: View {
    var doorAngle: Double

    var body: some View {
        ZStack {
            // Fridge body
            RoundedRectangle(cornerRadius: 26, style: .continuous)
                .fill(Color.appWhite)
                .shadow(color: .black.opacity(0.06), radius: 10, x: 0, y: 8)

            // Interior (visible when door opens)
            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .fill(Color.appBlue.opacity(0.12))
                .padding(10)

            // Door
            FridgeDoor()
                .rotation3DEffect(.degrees(doorAngle),
                                  axis: (x: 0, y: 1, z: 0),
                                  anchor: .leading,
                                  perspective: 0.6)
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("Fridge opening animation")
    }
}

private struct FridgeDoor: View {
    var body: some View {
        ZStack(alignment: .trailing) {
            RoundedRectangle(cornerRadius: 26, style: .continuous)
                .fill(Color.appWhite)
                .overlay(
                    RoundedRectangle(cornerRadius: 26, style: .continuous)
                        .stroke(Color.black.opacity(0.06), lineWidth: 1)
                )
            // Handle
            RoundedRectangle(cornerRadius: 3, style: .continuous)
                .fill(Color.appBrown)
                .frame(width: 6, height: 36)
                .padding(.trailing, 16)
        }
    }
}

#Preview {
    RootView()
}
