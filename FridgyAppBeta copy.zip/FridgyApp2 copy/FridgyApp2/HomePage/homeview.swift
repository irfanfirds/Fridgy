import SwiftUI

struct HomeView: View {
    @EnvironmentObject var store: FridgeStore
    @Binding var selectedTab: Tab

    @State private var showingExpiringItems = false
    @State private var showingAllItems = false
    @State private var showingAddItem = false

    // Track previous count to detect when items newly become "expiring soon"
    @State private var previousExpiringCount: Int = 0

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 20) {
                // Calendar/overview card
                TodayOverviewCard()
                    .padding(.horizontal, 20)
                    .accessibilityLabel("Today overview")

                // Add Item button on Home
                Button {
                    showingAddItem = true
                    UIImpactFeedbackGenerator(style: .light).impactOccurred()
                } label: {
                    HStack(spacing: 10) {
                        Image(systemName: "plus.circle.fill")
                            .font(.system(size: 20, weight: .semibold))
                        Text("Add Item")
                            .font(.system(size: 16, weight: .semibold))
                    }
                    .foregroundColor(.appWhite)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 14)
                    .background(
                        LinearGradient(colors: [.appBrown, .appDarkBrown],
                                       startPoint: .topLeading,
                                       endPoint: .bottomTrailing)
                    )
                    .cornerRadius(16)
                    .shadow(color: .appBrown.opacity(0.25), radius: 8, x: 0, y: 4)
                }
                .padding(.horizontal, 20)
                .accessibilityLabel("Add item")
                .accessibilityHint("Open the add item form")

                // Stats cards
                LazyVGrid(columns: [GridItem(.flexible(), spacing: 10), GridItem(.flexible(), spacing: 10)], spacing: 12) {
                    Button { showingExpiringItems = true } label: {
                        ModernStatsCard(title: "Expiring Soon", count: store.expiringSoon.count, subtitle: "Within 3 days", color: .appRed, icon: "exclamationmark.triangle.fill")
                    }
                    .accessibilityLabel("Expiring soon, \(store.expiringSoon.count) items")
                    Button { showingAllItems = true } label: {
                        ModernStatsCard(title: "Total Items", count: store.totalItems.count, subtitle: "In your fridge", color: .appBlue, icon: "refrigerator.fill")
                    }
                    .accessibilityLabel("Total items, \(store.totalItems.count)")
                }
                .padding(.horizontal, 20)

                // Expiring soon horizontal list
                if !store.expiringSoon.isEmpty {
                    VStack(alignment: .leading, spacing: 12) {
                        HStack {
                            Text("Items Expiring Soon")
                                .font(.headline)
                                .fontWeight(.semibold)
                                .foregroundColor(.appBlack)
                                .accessibilityAddTraits(.isHeader)
                                .accessibilityHint("Opens the Expiring Soon list")
                                .onTapGesture {
                                    showingExpiringItems = true
                                    UIImpactFeedbackGenerator(style: .light).impactOccurred()
                                }
                            Spacer()
                            Button("See All") { showingExpiringItems = true }
                                .font(.subheadline)
                                .fontWeight(.medium)
                                .foregroundColor(.appBrown)
                                .accessibilityHint("Show all expiring items")
                        }
                        .padding(.horizontal, 20)
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 12) {
                                ForEach(Array(store.expiringSoon.prefix(5))) { item in
                                    ExpiringItemCard(item: item)
                                }
                            }
                            .padding(.horizontal, 20)
                        }
                    }
                }

                Spacer(minLength: 100)
            }
        }
        .background(Color.appCream)
        .sheet(isPresented: $showingExpiringItems) { NavigationView { ExpiringItemsListView().environmentObject(store) } }
        .sheet(isPresented: $showingAllItems) { NavigationView { AllItemsListView().environmentObject(store) } }
        .sheet(isPresented: $showingAddItem) { AddEditItemView().environmentObject(store) }
        // Establish baseline so we don't auto-open on initial load
        .onAppear {
            previousExpiringCount = store.expiringSoon.count
        }
        // Auto-redirect to Expiring Soon when new items enter that state
        .onChange(of: store.expiringSoon.count) { _, newCount in
            if newCount > previousExpiringCount {
                showingExpiringItems = true
                UIImpactFeedbackGenerator(style: .light).impactOccurred()
            }
            previousExpiringCount = newCount
        }
    }
}

#Preview {
    // Provide a constant binding for preview
    HomeView(selectedTab: .constant(.home))
        .environmentObject(FridgeStore.sample)
}
