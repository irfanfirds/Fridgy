import SwiftUI
import PhotosUI
import UIKit
import AVFoundation // Import AVFoundation for camera permission check
import Photos // Import Photos for photo library permission check

struct AddEditItemView: View {
    @EnvironmentObject var store: FridgeStore
    @Environment(\.dismiss) var dismiss

    var itemToEdit: FridgeItem?

    @State private var name: String = ""
    @State private var amount: String = ""
    @State private var note: String = ""
    @State private var expiryDate: Date = Calendar.current.date(byAdding: .day, value: 1, to: Date())!
    @State private var category: ItemCategory = .other

    // Photo state
    @State private var showPhotoOptions = false
    @State private var showCamera = false
    @State private var showPhotoLibrary = false // New state variable
    @State private var selectedImage: UIImage?
    @State private var existingImageFilename: String?
    @State private var removeExistingOnSave = false
    @State private var showingSettingsAlert = false // New state for permission alert
    
    init(itemToEdit: FridgeItem? = nil) {
        self.itemToEdit = itemToEdit
        // State initializers will be set in onAppear
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("Item") {
                    TextField("Name", text: $name)
                        .autocorrectionDisabled(true)
                        .accessibilityLabel("Item name")
                    TextField("Amount (e.g. 1L, 2 pcs)", text: $amount)
                        .autocorrectionDisabled(true)
                        .accessibilityLabel("Amount")
                    TextField("Notes (optional)", text: $note)
                        .autocorrectionDisabled(true)
                        .accessibilityLabel("Notes")
                    Picker("Category", selection: $category) {
                        ForEach(ItemCategory.allCases, id: \.self) { c in
                            Text(c.rawValue).tag(c)
                        }
                    }
                    .accessibilityLabel("Category")
                }
                Section("Expiry") {
                    DatePicker("Expiry Date", selection: $expiryDate, displayedComponents: .date)
                        .accessibilityLabel("Expiry date")
                }
                Section("Photo") {
                    if let img = selectedImage {
                        Image(uiImage: img)
                            .resizable()
                            .scaledToFill()
                            .frame(maxWidth: .infinity)
                            .frame(height: 180)
                            .clipped()
                            .cornerRadius(12)
                            .accessibilityLabel("Selected photo")
                        HStack {
                            Button("Replace Photo") { showPhotoOptions = true }
                            Spacer()
                            Button("Remove Photo", role: .destructive) {
                                selectedImage = nil
                                removeExistingOnSave = true
                            }
                        }
                    } else if let filename = existingImageFilename,
                              let ui = UIImage(contentsOfFile: store.imageURL(for: filename).path) {
                        Image(uiImage: ui)
                            .resizable()
                            .scaledToFill()
                            .frame(maxWidth: .infinity)
                            .frame(height: 180)
                            .clipped()
                            .cornerRadius(12)
                            .accessibilityLabel("Current photo")
                        HStack {
                            Button("Change Photo") { showPhotoOptions = true }
                            Spacer()
                            Button("Remove Photo", role: .destructive) {
                                removeExistingOnSave = true
                                existingImageFilename = nil
                            }
                        }
                    } else {
                        Button {
                            showPhotoOptions = true
                            UIImpactFeedbackGenerator(style: .light).impactOccurred()
                        } label: {
                            Label("Add Photo", systemImage: "camera.fill")
                        }
                        .accessibilityHint("Take a photo or choose from library")
                    }
                }
            }
            .navigationTitle(itemToEdit == nil ? "Add Item" : "Edit Item")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") { saveTapped() }
                        .disabled(name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                        .accessibilityLabel("Save item")
                }
            }
            // Confirmation dialog to choose photo source
            .confirmationDialog("Add Photo", isPresented: $showPhotoOptions, titleVisibility: .visible) {
                // Take Photo button with permission check
                Button("Take Photo") {
                    CameraPermissionManager.checkAndRequestAccess { granted in
                        if granted {
                            showCamera = true
                        } else {
                            showingSettingsAlert = true
                        }
                    }
                }
                // Choose from Library button with permission check
                Button("Choose from Library") {
                    let status = PHPhotoLibrary.authorizationStatus(for: .readWrite)
                    switch status {
                    case .authorized, .limited:
                        showPhotoLibrary = true
                    case .notDetermined:
                        PHPhotoLibrary.requestAuthorization(for: .readWrite) { newStatus in
                            if newStatus == .authorized || newStatus == .limited {
                                showPhotoLibrary = true
                            } else {
                                showingSettingsAlert = true
                            }
                        }
                    case .denied, .restricted:
                        showingSettingsAlert = true
                    @unknown default:
                        break
                    }
                }
                Button("Cancel", role: .cancel) {}
            }
            // Present the CameraPicker
            .sheet(isPresented: $showCamera) {
                CameraPicker { img in
                    selectedImage = img
                    removeExistingOnSave = true
                }
            }
            // Present the PhotoLibraryPicker
            .sheet(isPresented: $showPhotoLibrary) {
                PhotoLibraryPicker { img in
                    selectedImage = img
                }
            }
            // Alert to guide users to settings if permissions are denied
            .alert("Access Required", isPresented: $showingSettingsAlert) {
                Button("Go to Settings", role: .cancel) {
                    CameraPermissionManager.openSettings()
                }
                Button("Cancel", role: .destructive) {}
            } message: {
                Text("Please enable access to your camera or photo library in Settings.")
            }
            .onAppear {
                if let it = itemToEdit {
                    name = it.name
                    amount = it.amount
                    note = it.note
                    expiryDate = it.expiryDate
                    category = it.category
                    existingImageFilename = it.imageFilename
                }
            }
        }
    }

    private func saveTapped() {
        let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }

        var finalFilename: String? = existingImageFilename

        if let img = selectedImage {
            if let old = existingImageFilename { store.deleteImage(named: old) }
            finalFilename = store.saveImage(img, prefix: "item")
        } else if removeExistingOnSave, let old = existingImageFilename {
            store.deleteImage(named: old)
            finalFilename = nil
        }

        if var edit = itemToEdit {
            edit.name = trimmed
            edit.amount = amount
            edit.note = note
            edit.expiryDate = expiryDate
            edit.category = category
            edit.imageFilename = finalFilename
            store.update(edit)
        } else {
            var newItem = FridgeItem(name: trimmed, expiryDate: expiryDate, amount: amount, note: note, category: category)
            newItem.imageFilename = finalFilename
            store.add(newItem)
        }
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
        dismiss()
    }
}

#Preview {
    AddEditItemView().environmentObject(FridgeStore.sample)
}
