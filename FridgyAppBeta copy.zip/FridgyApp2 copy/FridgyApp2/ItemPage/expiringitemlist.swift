import SwiftUI

struct ExpiringItemsListView: View {
    @EnvironmentObject var store: FridgeStore
    @State private var pendingDelete: IndexSet? = nil
    @State private var showConfirm = false

    var body: some View {
        Group {
            if store.expiringSoon.isEmpty {
                VStack(spacing: 12) {
                    Image(systemName: "checkmark.seal")
                        .font(.system(size: 42)).foregroundColor(.appDarkBrown)
                    Text("No expiring items").font(.headline).foregroundColor(.appBlack)
                    Text("You’re good for the next few days").font(.subheadline).foregroundColor(.appDarkBrown)
                }.padding()
            } else {
                List {
                    ForEach(store.expiringSoon) { item in
                        NavigationLink(destination: ItemDetailView(item: item).environmentObject(store)) {
                            ModernItemRow(item: item, showUrgent: true)
                        }
                        .buttonStyle(PlainButtonStyle())
                    }
                    .onDelete { offsets in
                        pendingDelete = offsets
                        showConfirm = true
                    }
                }
                .listStyle(.plain)
            }
        }
        .navigationTitle("Expiring Soon")
        .confirmationDialog("Delete these items?", isPresented: $showConfirm, titleVisibility: .visible) {
            Button("Delete", role: .destructive) {
                if let o = pendingDelete {
                    store.deleteItems(at: o, from: store.expiringSoon)
                    pendingDelete = nil
                }
            }
            Button("Cancel", role: .cancel) { pendingDelete = nil }
        }
    }
}

#Preview {
    ExpiringItemsListView().environmentObject(FridgeStore.sample)
}
