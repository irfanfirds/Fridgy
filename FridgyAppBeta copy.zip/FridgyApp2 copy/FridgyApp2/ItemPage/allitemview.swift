import SwiftUI

struct AllItemsListView: View {
    @EnvironmentObject var store: FridgeStore
    @State private var pendingDelete: IndexSet? = nil
    @State private var showConfirm = false

    var body: some View {
        Group {
            if store.totalItems.isEmpty {
                VStack(spacing: 12) {
                    Image(systemName: "tray")
                        .font(.system(size: 42))
                        .foregroundColor(.appDarkBrown)
                    Text("No items").font(.headline).foregroundColor(.appBlack)
                    Text("Use the + button to add items").font(.subheadline).foregroundColor(.appDarkBrown)
                }
                .padding()
            } else {
                ScrollView(showsIndicators: false) {
                    LazyVStack(spacing: 12) {
                        ForEach(store.totalItems) { item in
                            NavigationLink(destination: ItemDetailView(item: item).environmentObject(store)) {
                                ModernItemRow(item: item)
                                    .padding(12)
                                    .background(Color.appWhite)
                                    .cornerRadius(12)
                                    .shadow(color: .black.opacity(0.05), radius: 4, x: 0, y: 2)
                            }
                            .buttonStyle(PlainButtonStyle())
                        }
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 16) // add breathing room from the top edge
                }
                .background(Color.appCream)
            }
        }
        .navigationTitle("All Items")
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                NavigationLink("Add", destination: AddEditItemView().environmentObject(store))
            }
        }
        .confirmationDialog("Delete these items?", isPresented: $showConfirm, titleVisibility: .visible) {
            Button("Delete", role: .destructive) {
                if let o = pendingDelete { store.deleteItems(at: o, from: store.totalItems); pendingDelete = nil }
            }
            Button("Cancel", role: .cancel) { pendingDelete = nil }
        }
    }
}

#Preview {
    AllItemsListView().environmentObject(FridgeStore.sample)
}
