import SwiftUI
import UIKit

struct ItemDetailView: View {
    @EnvironmentObject var store: FridgeStore
    @Environment(\.dismiss) var dismiss
    let item: FridgeItem

    @State private var showEdit = false
    @State private var showRemoveConfirm = false

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 24) {

                // Photo (if any)
                if let filename = item.imageFilename,
                   let ui = UIImage(contentsOfFile: store.imageURL(for: filename).path) {
                    Image(uiImage: ui)
                        .resizable()
                        .scaledToFill()
                        .frame(maxWidth: .infinity)
                        .frame(height: 220)
                        .clipped()
                        .cornerRadius(24)
                        .overlay(
                            RoundedRectangle(cornerRadius: 24).stroke(Color.black.opacity(0.05), lineWidth: 1)
                        )
                        .accessibilityLabel("Item photo")
                        .padding(.horizontal)
                }

                // Hero section
                VStack(spacing: 16) {
                    Image(systemName: item.category.icon)
                        .font(.system(size: 60))
                        .foregroundColor(item.category.color)
                        .frame(width: 120, height: 120)
                        .background(item.category.color.opacity(0.2))
                        .cornerRadius(30)

                    VStack(spacing: 8) {
                        Text(item.name)
                            .font(.title)
                            .fontWeight(.bold)
                            .foregroundColor(.appBlack)
                            .multilineTextAlignment(.center)
                            .accessibilityAddTraits(.isHeader)

                        HStack(spacing: 16) {
                            Text(item.amount)
                                .font(.subheadline)
                                .foregroundColor(.appDarkBrown)

                            Text("•")
                                .foregroundColor(.appDarkBrown.opacity(0.5))

                            Text(item.category.rawValue)
                                .font(.subheadline)
                                .foregroundColor(item.category.color)
                                .fontWeight(.medium)
                        }
                    }
                }
                .padding(30)
                .background(Color.appWhite)
                .cornerRadius(24)
                .shadow(color: .black.opacity(0.05), radius: 8, x: 0, y: 4)

                // Details cards
                VStack(spacing: 16) {
                    // Expiry info
                    VStack(alignment: .leading, spacing: 12) {
                        HStack {
                            Image(systemName: "calendar.badge.clock")
                                .foregroundColor(item.isExpiringSoon ? .appRed : .appGreen)
                            Text("Expiry Information")
                                .font(.headline)
                                .fontWeight(.semibold)
                                .foregroundColor(.appBlack)
                        }

                        VStack(alignment: .leading, spacing: 8) {
                            HStack {
                                Text("Expires on:")
                                    .foregroundColor(.appDarkBrown.opacity(0.8))
                                Spacer()
                                Text(item.expiryDate, style: .date)
                                    .fontWeight(.medium)
                                    .foregroundColor(.appBlack)
                            }

                            HStack {
                                Text("Days remaining:")
                                    .foregroundColor(.appDarkBrown.opacity(0.8))
                                Spacer()
                                Text("\(item.daysUntilExpiry) days")
                                    .fontWeight(.medium)
                                    .foregroundColor(item.isExpiringSoon ? .appRed : .appGreen)
                            }
                        }
                        .font(.subheadline)
                    }
                    .padding(16)
                    .background(Color.appWhite)
                    .cornerRadius(16)
                    .shadow(color: .black.opacity(0.05), radius: 4, x: 0, y: 2)

                    // Notes
                    if !item.note.isEmpty {
                        VStack(alignment: .leading, spacing: 12) {
                            HStack {
                                Image(systemName: "note.text")
                                    .foregroundColor(.appBrown)
                                Text("Notes")
                                    .font(.headline)
                                    .fontWeight(.semibold)
                                    .foregroundColor(.appBlack)
                            }
                            Text(item.note)
                                .foregroundColor(.appDarkBrown)
                        }
                        .padding(16)
                        .background(Color.appWhite)
                        .cornerRadius(16)
                        .shadow(color: .black.opacity(0.05), radius: 4, x: 0, y: 2)
                    }
                }
                .padding(.horizontal)

                // Actions
                VStack(spacing: 12) {
                    Button { showEdit = true } label: {
                        Text("Edit Item")
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.appBrown)
                            .foregroundColor(.appWhite)
                            .cornerRadius(10)
                    }
                    .accessibilityLabel("Edit item")
                    Button(role: .destructive) { showRemoveConfirm = true } label: {
                        Text("Remove Item")
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.red)
                            .foregroundColor(.white)
                            .cornerRadius(10)
                    }
                    .accessibilityLabel("Remove item")
                }
                .padding(.horizontal)
            }
            .padding(.vertical)
        }
        .background(Color.appCream)
        .navigationTitle("Item Details")
        .sheet(isPresented: $showEdit) { AddEditItemView(itemToEdit: item).environmentObject(store) }
        .confirmationDialog("Move this item to history? This will cancel reminders.", isPresented: $showRemoveConfirm, titleVisibility: .visible) {
            Button("Remove", role: .destructive) {
                NotificationManager.shared.cancelNotification(for: item)
                store.remove(item: item)
                UIImpactFeedbackGenerator(style: .light).impactOccurred()
                dismiss()
            }
            Button("Cancel", role: .cancel) {}
        }
    }
}

#Preview {
    ItemDetailView(item: FridgeItem(name: "Cheese", expiryDate: Date().addingTimeInterval(86400), amount: "200g", note: "Parmesan")).environmentObject(FridgeStore.sample)
}
