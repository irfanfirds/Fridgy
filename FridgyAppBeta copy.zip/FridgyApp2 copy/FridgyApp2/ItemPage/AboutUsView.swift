import SwiftUI

struct AboutUsView: View {
    var body: some View {
        ZStack {
            Color.appCream.ignoresSafeArea()

            VStack(spacing: 20) {
                AppIconView()
                    .frame(width: 140, height: 140)
                    .shadow(color: .black.opacity(0.15), radius: 12, x: 0, y: 6)

                Text(Bundle.main.appDisplayName)
                    .font(.title2.weight(.semibold))
                    .foregroundColor(.appBlack)

                Text("Version \(Bundle.main.appVersion) (\(Bundle.main.appBuild))")
                    .font(.subheadline)
                    .foregroundColor(.appDarkBrown)

                Spacer().frame(height: 8)

                Text("Fridgy helps you track items in your fridge, avoid waste, and plan meals with ease.")
                    .font(.body)
                    .foregroundColor(.appDarkBrown)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 24)
            }
            .padding(.top, 60)
        }
        .navigationTitle("About Us")
        .navigationBarTitleDisplayMode(.inline)
    }
}

private struct AppIconView: View {
    var body: some View {
        Group {
            if let image = AppIconProvider.primaryAppIconImage() {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFit()
                    .clipShape(RoundedRectangle(cornerRadius: 28, style: .continuous))
            } else {
                // Fallback if icon lookup fails (e.g. in previews)
                Image(systemName: "app.fill")
                    .resizable()
                    .scaledToFit()
                    .foregroundColor(.appBrown)
                    .padding(24)
                    .background(Color.appLightGray)
                    .clipShape(RoundedRectangle(cornerRadius: 28, style: .continuous))
            }
        }
    }
}

private enum AppIconProvider {
    // Tries to fetch the primary app icon image from Info.plist CFBundleIcons
    static func primaryAppIconImage() -> UIImage? {
        #if canImport(UIKit)
        guard
            let info = Bundle.main.infoDictionary,
            let icons = info["CFBundleIcons"] as? [String: Any],
            let primary = icons["CFBundlePrimaryIcon"] as? [String: Any],
            let files = primary["CFBundleIconFiles"] as? [String],
            let iconName = files.last
        else { return nil }

        return UIImage(named: iconName)
        #else
        return nil
        #endif
    }
}

private extension Bundle {
    var appDisplayName: String {
        if let name = object(forInfoDictionaryKey: "CFBundleDisplayName") as? String {
            return name
        }
        return object(forInfoDictionaryKey: "CFBundleName") as? String ?? "App"
    }

    var appVersion: String {
        object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "1.0"
    }

    var appBuild: String {
        object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "1"
    }
}

#Preview {
    NavigationStack {
        AboutUsView()
    }
}
