import SwiftUI

struct CategoryItemsPage: View {
    @EnvironmentObject var store: FridgeStore
    let category: ItemCategory
    @State private var showAdd = false
    @State private var itemToEdit: FridgeItem? = nil
    @State private var pendingDelete: FridgeItem? = nil

    private var itemsInCategory: [FridgeItem] {
        store.items.filter { $0.removedDate == nil && $0.category == category }
            .sorted { $0.name.lowercased() < $1.name.lowercased() }
    }

    var body: some View {
        Group {
            if itemsInCategory.isEmpty {
                VStack(spacing: 12) {
                    Image(systemName: category.icon)
                        .font(.system(size: 42))
                        .foregroundColor(category.color)
                    Text("No items in \(category.rawValue)")
                        .font(.headline)
                        .foregroundColor(.appBlack)
                    Text("Tap + to add an item")
                        .font(.subheadline)
                        .foregroundColor(.appDarkBrown)
                }.padding()
            } else {
                ScrollView(showsIndicators: false) {
                    LazyVStack(spacing: 12) {
                        ForEach(itemsInCategory) { item in
                            NavigationLink(destination: ItemDetailView(item: item).environmentObject(store)) {
                                ModernItemRow(item: item)
                            }
                            .buttonStyle(PlainButtonStyle())
                            .contextMenu {
                                Button("Edit") { itemToEdit = item; showAdd = true }
                                Button("Remove", role: .destructive) { pendingDelete = item }
                            }
                        }
                        .padding(.horizontal, 16)
                        .padding(.top, 8)
                    }
                }
                .background(Color.appCream)
            }
        }
        .navigationTitle(category.rawValue)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Button { itemToEdit = nil; showAdd = true } label: { Image(systemName: "plus") }
            }
        }
        .sheet(isPresented: $showAdd) {
            AddEditItemView(itemToEdit: itemToEdit)
                .environmentObject(store)
                .onAppear {
                    // Pre-fill category when adding
                    if itemToEdit == nil {
                        // no direct binding; we rely on default form and set on save via wrapper
                    }
                }
        }
        .alert("Remove this item?", isPresented: Binding(get: { pendingDelete != nil }, set: { if !$0 { pendingDelete = nil } })) {
            Button("Cancel", role: .cancel) { pendingDelete = nil }
            Button("Remove", role: .destructive) {
                if let it = pendingDelete { store.remove(item: it); pendingDelete = nil }
            }
        }
    }
}


