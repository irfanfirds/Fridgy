import SwiftUI

struct ItemRowView: View {
    @EnvironmentObject var store: FridgeStore
    let item: FridgeItem
    var showUrgent: Bool = false

    var body: some View {
        NavigationLink(destination: ItemDetailView(item: item).environmentObject(store)) {
            ModernItemRow(item: item, showUrgent: showUrgent)
        }
        .buttonStyle(PlainButtonStyle())
    }
}

// Modern card-style row used across lists
struct ModernItemRow: View {
    let item: FridgeItem
    var showUrgent: Bool = false

    var body: some View {
        HStack(spacing: 16) {
            // Category Icon
            Image(systemName: item.category.icon)
                .font(.title3)
                .foregroundColor(item.category.color)
                .frame(width: 44, height: 44)
                .background(item.category.color.opacity(0.2))
                .cornerRadius(12)

            // Item Info
            VStack(alignment: .leading, spacing: 4) {
                HStack {
                    Text(item.name)
                        .font(.subheadline)
                        .fontWeight(.semibold)
                        .foregroundColor(.appBlack)

                    Spacer()

                    if showUrgent {
                        Text("\(item.daysUntilExpiry)d left")
                            .font(.caption)
                            .fontWeight(.medium)
                            .foregroundColor(Color.appRed)
                            .padding(.horizontal, 8)
                            .padding(.vertical, 4)
                            .background(Color.appRed.opacity(0.1))
                            .cornerRadius(8)
                    }
                }

                HStack {
                    Text(item.amount)
                        .font(.caption)
                        .foregroundColor(.appDarkBrown.opacity(0.8))

                    Text("•")
                        .font(.caption)
                        .foregroundColor(.appDarkBrown.opacity(0.5))

                    Text(item.expiryDate, style: .date)
                        .font(.caption)
                        .foregroundColor(showUrgent ? Color.appRed : Color.appDarkBrown.opacity(0.8))
                }

                if !item.note.isEmpty {
                    Text(item.note)
                        .font(.caption)
                        .foregroundColor(.appDarkBrown.opacity(0.6))
                        .lineLimit(1)
                }
            }
        }
        .padding(16)
        .background(Color.appWhite)
        .cornerRadius(16)
        .shadow(color: .black.opacity(0.05), radius: 4, x: 0, y: 2)
    }
}

#Preview {
    NavigationStack {
        ItemRowView(
            item: FridgeItem(
                name: "Milk",
                expiryDate: Date().addingTimeInterval(86400 * 2),
                amount: "1L",
                note: "2%",
                category: .dairy
            ),
            showUrgent: true
        )
        .environmentObject(FridgeStore.sample)
        .padding()
    }
}
