import SwiftUI

struct CustomTabBar: View {
    @Binding var selectedTab: Tab
    @Namespace private var bubbleNamespace

    // Only show the four main tabs; exclude .add
    private var tabs: [Tab] {
        Tab.allCases.filter { $0 != .add }
    }

    var body: some View {
        // Horizontally scrollable to show full text beside the icon
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 12) {
                ForEach(tabs, id: \.self) { tab in
                    Button {
                        withAnimation(.spring(response: 0.28, dampingFraction: 0.86, blendDuration: 0.2)) {
                            selectedTab = tab
                        }
                        UIImpactFeedbackGenerator(style: .light).impactOccurred()
                    } label: {
                        HStack(spacing: 10) {
                            Image(systemName: tab.icon)
                                .font(.headline) // Dynamic Type-friendly
                            Text(tab.rawValue)
                                .font(.subheadline) // Dynamic Type-friendly
                                .fontWeight(selectedTab == tab ? .semibold : .regular)
                                .fixedSize(horizontal: true, vertical: false)
                        }
                        .foregroundColor(tab == selectedTab ? .appWhite : .appBlack)
                        .padding(.horizontal, 18)
                        .padding(.vertical, 12)
                        .background(
                            ZStack {
                                if tab == selectedTab {
                                    Capsule()
                                        .fill(
                                            LinearGradient(
                                                colors: [.appBrown, .appDarkBrown],
                                                startPoint: .topLeading,
                                                endPoint: .bottomTrailing
                                            )
                                        )
                                        .matchedGeometryEffect(id: "bubbleFill", in: bubbleNamespace)
                                        .shadow(color: .appBrown.opacity(0.20), radius: 8, x: 0, y: 4)
                                } else {
                                    Capsule()
                                        .fill(Color.appWhite)
                                        .overlay(
                                            Capsule()
                                                .stroke(Color.appBrown.opacity(0.12), lineWidth: 1)
                                        )
                                }
                            }
                        )
                        .contentShape(Rectangle())
                    }
                    .accessibilityElement(children: .ignore)
                    .accessibilityLabel(tab.rawValue)
                    .accessibilityAddTraits(selectedTab == tab ? [.isSelected, .isButton] : .isButton)
                    .accessibilityHint("Switch to \(tab.rawValue) tab")
                }
            }
            .padding(.horizontal, 20)
            .padding(.vertical, 12)
        }
        .background(Color.clear)
    }
}

#Preview {
    CustomTabBar(selectedTab: .constant(.home))
        .previewLayout(.sizeThatFits)
        .padding()
}
