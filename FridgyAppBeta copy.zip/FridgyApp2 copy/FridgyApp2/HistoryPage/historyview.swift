import SwiftUI

struct HistoryView: View {
    @EnvironmentObject var store: FridgeStore
    @State private var itemPendingDelete: FridgeItem? = nil
    @State private var showConfirm = false

    var body: some View {
        Group {
            if store.history.isEmpty {
                VStack(spacing: 12) {
                    Image(systemName: "clock.arrow.circlepath")
                        .font(.system(size: 48))
                        .foregroundColor(.appDarkBrown)
                    Text("No history yet")
                        .font(.headline)
                        .foregroundColor(.appBlack)
                    Text("Removed items will appear here")
                        .font(.subheadline)
                        .foregroundColor(.appDarkBrown)
                }
                .padding()
                .frame(maxWidth: .infinity, maxHeight: .infinity) // Center within available page space
            } else {
                ScrollView(showsIndicators: false) {
                    LazyVStack(spacing: 12) {
                        ForEach(store.history) { item in
                            ZStack(alignment: .topTrailing) {
                                // Row content as a tappable card to open details
                                NavigationLink(destination: ItemDetailView(item: item).environmentObject(store)) {
                                    ModernItemRow(item: item)
                                        .padding(12)
                                        .background(Color.appWhite)
                                        .cornerRadius(16)
                                        .shadow(color: .black.opacity(0.05), radius: 4, x: 0, y: 2)
                                }
                                .buttonStyle(PlainButtonStyle())

                                // Delete button on the card
                                Button {
                                    itemPendingDelete = item
                                    showConfirm = true
                                } label: {
                                    Image(systemName: "trash.fill")
                                        .font(.system(size: 14, weight: .semibold))
                                        .foregroundColor(.white)
                                        .padding(8)
                                        .background(Color.red)
                                        .clipShape(Capsule())
                                        .shadow(color: .black.opacity(0.1), radius: 2, x: 0, y: 1)
                                }
                                .padding(8)
                                .accessibilityLabel("Delete history item")
                            }
                        }
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 12)
                }
                .background(Color.appCream)
                .confirmationDialog(
                    "Delete this history entry? This cannot be undone.",
                    isPresented: $showConfirm,
                    titleVisibility: .visible
                ) {
                    Button("Delete", role: .destructive) {
                        if let item = itemPendingDelete {
                            // Remove the item from the main store by id
                            store.items.removeAll { $0.id == item.id }
                        }
                        itemPendingDelete = nil
                    }
                    Button("Cancel", role: .cancel) { itemPendingDelete = nil }
                }
            }
        }
        .background(Color.appCream)
    }
}

#Preview {
    HistoryView().environmentObject(FridgeStore.sample)
}
