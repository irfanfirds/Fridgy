import SwiftUI

struct RecipeListView: View {
    @EnvironmentObject var store: FridgeStore
    @State private var showAdd = false

    struct RecipeCard: View {
        let recipe: Recipe
        var body: some View {
            HStack(alignment: .center, spacing: 12) {
                Image(systemName: recipe.category.icon)
                    .foregroundColor(recipe.category.color)
                    .frame(width: 36, height: 36)
                    .background(recipe.category.color.opacity(0.2))
                    .cornerRadius(10)
                VStack(alignment: .leading, spacing: 4) {
                    Text(recipe.title)
                        .font(.headline)
                        .foregroundColor(.appBlack)
                    if !recipe.ingredients.isEmpty {
                        Text(recipe.ingredients)
                            .font(.caption)
                            .foregroundColor(.appDarkBrown)
                            .lineLimit(1)
                    }
                }
                Spacer()
            }
            .accessibilityElement(children: .combine)
            .accessibilityLabel("\(recipe.title), \(recipe.category.rawValue) recipe")
        }
    }

    var body: some View {
        ZStack {
            ScrollView(showsIndicators: false) {
                VStack(spacing: 16) {
                    if !store.recipes.isEmpty {
                        LazyVStack(spacing: 12) {
                            ForEach(store.recipes) { recipe in
                                NavigationLink(destination: RecipeDetailView(recipe: recipe).environmentObject(store)) {
                                    RecipeCard(recipe: recipe)
                                        .padding(12)
                                        .background(Color.appWhite)
                                        .cornerRadius(12)
                                        .shadow(color: .black.opacity(0.05), radius: 4, x: 0, y: 2)
                                }
                                .buttonStyle(PlainButtonStyle())
                                .contextMenu {
                                    Button(role: .destructive) {
                                        if let idx = store.recipes.firstIndex(where: { $0.id == recipe.id }) {
                                            if let fn = store.recipes[idx].imageFilename {
                                                store.deleteImage(named: fn)
                                            }
                                            store.recipes.remove(at: idx)
                                        }
                                    } label: { Label("Delete", systemImage: "trash") }
                                }
                            }
                        }
                        .padding(.horizontal, 20)
                    }

                    // Provide space at bottom so content isn't obscured by the fixed button
                    Spacer(minLength: 100)
                }
                .padding(.top, 16)
            }

            // Centered empty state overlay (does not block taps)
            if store.recipes.isEmpty {
                VStack(spacing: 12) {
                    Image(systemName: "book")
                        .font(.system(size: 42))
                        .foregroundColor(.appDarkBrown)
                    Text("No recipes yet").font(.headline).foregroundColor(.appBlack)
                    Text("Tap Add Recipe to create one").font(.subheadline).foregroundColor(.appDarkBrown)
                }
                .padding()
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .allowsHitTesting(false)
                .accessibilityElement(children: .combine)
                .accessibilityLabel("No recipes. Tap Add Recipe to create one.")
            }
        }
        .background(Color.appCream)
        // Fixed bottom Add Recipe button that does not scroll
        .safeAreaInset(edge: .bottom) {
            VStack {
                Button {
                    showAdd = true
                    UIImpactFeedbackGenerator(style: .light).impactOccurred()
                } label: {
                    HStack(spacing: 10) {
                        Image(systemName: "plus.circle.fill")
                            .font(.system(size: 20, weight: .semibold))
                        Text("Add Recipe")
                            .font(.system(size: 16, weight: .semibold))
                    }
                    .foregroundColor(.appWhite)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 14)
                    .background(
                        LinearGradient(colors: [.appBrown, .appDarkBrown],
                                       startPoint: .topLeading,
                                       endPoint: .bottomTrailing)
                    )
                    .cornerRadius(16)
                    .shadow(color: .appBrown.opacity(0.25), radius: 8, x: 0, y: 4)
                }
                .padding(.horizontal, 20)
                .accessibilityLabel("Add recipe")

                // Small spacer to breathe above home indicator
                Color.clear.frame(height: 8)
            }
            .background(
                // Match page background so it looks attached, and blur if desired
                Color.appCream.ignoresSafeArea()
            )
        }
        .sheet(isPresented: $showAdd) { AddEditRecipeView().environmentObject(store) }
    }
}

#Preview {
    RecipeListView().environmentObject(FridgeStore.sample)
}
