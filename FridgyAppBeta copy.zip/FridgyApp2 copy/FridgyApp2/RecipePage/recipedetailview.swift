import SwiftUI
import UIKit

struct RecipeDetailView: View {
    @EnvironmentObject var store: FridgeStore
    @Environment(\.dismiss) var dismiss
    var recipe: Recipe

    @State private var showEdit = false
    @State private var showDeleteConfirm = false

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 16) {
                // Photo header (if any)
                if let filename = recipe.imageFilename,
                   let ui = UIImage(contentsOfFile: store.imageURL(for: filename).path) {
                    Image(uiImage: ui)
                        .resizable()
                        .scaledToFill()
                        .frame(maxWidth: .infinity)
                        .frame(height: 220)
                        .clipped()
                        .cornerRadius(16)
                        .overlay(
                            RoundedRectangle(cornerRadius: 16).stroke(Color.black.opacity(0.05), lineWidth: 1)
                        )
                        .accessibilityLabel("Recipe photo")
                }

                // Header card
                HStack(alignment: .center, spacing: 12) {
                    Image(systemName: recipe.category.icon)
                        .foregroundColor(recipe.category.color)
                        .frame(width: 40, height: 40)
                        .background(recipe.category.color.opacity(0.2))
                        .cornerRadius(12)

                    Text(recipe.title)
                        .font(.title2).bold().foregroundColor(.appBlack)
                        .accessibilityAddTraits(.isHeader)
                }
                .padding(16)
                .background(Color.appWhite)
                .cornerRadius(12)
                .shadow(color: .black.opacity(0.05), radius: 4, x: 0, y: 2)

                // Ingredients card
                VStack(alignment: .leading, spacing: 8) {
                    Text("Ingredients").font(.headline).foregroundColor(.appBlack)
                    Text(recipe.ingredients).foregroundColor(.appDarkBrown)
                }
                .padding(16)
                .background(Color.appWhite)
                .cornerRadius(12)
                .shadow(color: .black.opacity(0.05), radius: 4, x: 0, y: 2)

                // Notes card
                if !recipe.notes.isEmpty {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Notes").font(.headline).foregroundColor(.appBlack)
                        Text(recipe.notes).foregroundColor(.appDarkBrown)
                    }
                    .padding(16)
                    .background(Color.appWhite)
                    .cornerRadius(12)
                    .shadow(color: .black.opacity(0.05), radius: 4, x: 0, y: 2)
                }
                
                // Add a Spacer to push content to the top
                Spacer()
            }
            .padding(.horizontal)
            .padding(.top, 60)
            .frame(maxWidth: .infinity, maxHeight: .infinity) // Make the VStack fill all available space
        }
        .background(Color.appCream.ignoresSafeArea(.all, edges: .all)) // Fill the entire safe area
        .navigationTitle("Recipe")
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Menu {
                    Button("Edit") { showEdit = true }
                    Button("Delete", role: .destructive) { showDeleteConfirm = true }
                } label: { Image(systemName: "ellipsis.circle") }
            }
        }
        .sheet(isPresented: $showEdit) {
            AddEditRecipeView(recipeToEdit: recipe).environmentObject(store)
        }
        .confirmationDialog("Delete this recipe?", isPresented: $showDeleteConfirm, titleVisibility: .visible) {
            Button("Delete", role: .destructive) {
                if let idx = store.recipes.firstIndex(where: { $0.id == recipe.id }) {
                    if let fn = store.recipes[idx].imageFilename {
                        store.deleteImage(named: fn)
                    }
                    store.recipes.remove(at: idx)
                }
                dismiss()
            }
            Button("Cancel", role: .cancel) {}
        }
    }
}

#Preview {
    RecipeDetailView(recipe: Recipe(title: "Test", ingredients: "A\nB", notes: "X"))
        .environmentObject(FridgeStore.sample)
}
