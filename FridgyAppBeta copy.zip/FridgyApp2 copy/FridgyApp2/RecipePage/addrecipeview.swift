import SwiftUI
import PhotosUI
import UIKit

struct AddEditRecipeView: View {
    @EnvironmentObject var store: FridgeStore
    @Environment(\.dismiss) var dismiss

    var recipeToEdit: Recipe? = nil

    @State private var title: String = ""
    @State private var ingredients: String = ""
    @State private var notes: String = ""
    @State private var category: RecipeCategory = .dinner

    // Photo state
    @State private var showPhotoOptions = false
    @State private var showCamera = false
    @State private var pickedItem: PhotosPickerItem?
    @State private var selectedImage: UIImage?
    @State private var existingImageFilename: String?
    @State private var removeExistingOnSave = false

    var body: some View {
        NavigationStack {
            Form {
                Section("Recipe") {
                    TextField("Title", text: $title)
                        .autocorrectionDisabled(true)
                        .accessibilityLabel("Recipe title")
                }
                Section("Category") {
                    Picker("Category", selection: $category) {
                        ForEach(RecipeCategory.allCases, id: \.self) { c in
                            Text(c.rawValue).tag(c)
                        }
                    }
                    .accessibilityLabel("Recipe category")
                }
                Section("Ingredients") {
                    TextEditor(text: $ingredients)
                        .frame(minHeight: 120)
                        .autocorrectionDisabled(true)
                        .accessibilityLabel("Ingredients")
                }
                Section("Notes") {
                    TextEditor(text: $notes)
                        .frame(minHeight: 80)
                        .autocorrectionDisabled(true)
                        .accessibilityLabel("Notes")
                }
                Section("Photo") {
                    if let img = selectedImage {
                        Image(uiImage: img)
                            .resizable()
                            .scaledToFill()
                            .frame(maxWidth: .infinity)
                            .frame(height: 180)
                            .clipped()
                            .cornerRadius(12)
                            .accessibilityLabel("Selected recipe photo")
                        HStack {
                            Button("Replace Photo") { showPhotoOptions = true }
                            Spacer()
                            Button("Remove Photo", role: .destructive) {
                                selectedImage = nil
                                removeExistingOnSave = true
                            }
                        }
                    } else if let filename = existingImageFilename,
                              let ui = UIImage(contentsOfFile: store.imageURL(for: filename).path) {
                        Image(uiImage: ui)
                            .resizable()
                            .scaledToFill()
                            .frame(maxWidth: .infinity)
                            .frame(height: 180)
                            .clipped()
                            .cornerRadius(12)
                            .accessibilityLabel("Current recipe photo")
                        HStack {
                            Button("Change Photo") { showPhotoOptions = true }
                            Spacer()
                            Button("Remove Photo", role: .destructive) {
                                removeExistingOnSave = true
                                existingImageFilename = nil
                            }
                        }
                    } else {
                        Button {
                            showPhotoOptions = true
                            UIImpactFeedbackGenerator(style: .light).impactOccurred()
                        } label: {
                            Label("Add Photo", systemImage: "camera.fill")
                        }
                        .accessibilityHint("Take a photo or choose from library")
                    }
                }
            }
            .navigationTitle(recipeToEdit == nil ? "Add Recipe" : "Edit Recipe")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") {
                        save()
                    }
                    .disabled(title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || ingredients.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                    .accessibilityLabel("Save recipe")
                }
            }
            .confirmationDialog("Add Photo", isPresented: $showPhotoOptions, titleVisibility: .visible) {
                Button("Take Photo") { showCamera = true }
                PhotosPicker(selection: $pickedItem, matching: .images, photoLibrary: .shared()) {
                    Text("Choose from Library")
                }
                Button("Cancel", role: .cancel) {}
            }
            .sheet(isPresented: $showCamera) {
                CameraPicker { img in
                    selectedImage = img
                    removeExistingOnSave = true
                }
            }
            .onChange(of: pickedItem) { _, newItem in
                guard let newItem else { return }
                Task {
                    if let data = try? await newItem.loadTransferable(type: Data.self),
                       let img = UIImage(data: data) {
                        selectedImage = img
                        removeExistingOnSave = true
                    }
                }
            }
            .onAppear {
                if let r = recipeToEdit {
                    title = r.title; ingredients = r.ingredients; notes = r.notes; category = r.category
                    existingImageFilename = r.imageFilename
                }
            }
        }
    }

    private func save() {
        let t = title.trimmingCharacters(in: .whitespacesAndNewlines)
        let i = ingredients.trimmingCharacters(in: .whitespacesAndNewlines)
        let n = notes.trimmingCharacters(in: .whitespacesAndNewlines)

        var finalFilename: String? = existingImageFilename

        if let img = selectedImage {
            if let old = existingImageFilename { store.deleteImage(named: old) }
            finalFilename = store.saveImage(img, prefix: "recipe")
        } else if removeExistingOnSave, let old = existingImageFilename {
            store.deleteImage(named: old)
            finalFilename = nil
        }

        if var r = recipeToEdit {
            r.title = t; r.ingredients = i; r.notes = n; r.category = category; r.imageFilename = finalFilename
            store.updateRecipe(r)
        } else {
            let newR = Recipe(title: t, ingredients: i, notes: n, imageFilename: finalFilename, category: category)
            store.addRecipe(newR)
        }
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
        dismiss()
    }
}

#Preview {
    AddEditRecipeView().environmentObject(FridgeStore.sample)
}
