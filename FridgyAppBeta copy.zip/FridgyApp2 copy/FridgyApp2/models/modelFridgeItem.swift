import Foundation

struct FridgeItem: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    var name: String
    var expiryDate: Date
    var amount: String
    var note: String
    var removedDate: Date?
    var category: ItemCategory = .other
    var imageFilename: String? = nil

    var daysUntilExpiry: Int {
        Calendar.current.dateComponents([.day],
                                        from: Calendar.current.startOfDay(for: Date()),
                                        to: Calendar.current.startOfDay(for: expiryDate)).day ?? 0
    }

    var isExpiringSoon: Bool { (0...3).contains(daysUntilExpiry) }
    var isExpired: Bool { daysUntilExpiry < 0 }
}
