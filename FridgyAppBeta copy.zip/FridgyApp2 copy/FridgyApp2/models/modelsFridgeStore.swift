import Foundation
import Combine
import SwiftUI
import UIKit

@MainActor
final class FridgeStore: ObservableObject {
    @Published var items: [FridgeItem] = []
    @Published var recipes: [Recipe] = []

    // MARK: - Persistence
    private struct AppDatabase: Codable {
        var items: [FridgeItem]
        var recipes: [Recipe]
    }

    // Inline JSON persistence (replaces JSONStore)
    private let dbURL: URL
    private let encoder: JSONEncoder
    private let decoder: JSONDecoder

    private var cancellables: Set<AnyCancellable> = []
    private var isRestoring = false

    init() {
        // Configure persistence URL and coders
        let dir = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        self.dbURL = dir.appendingPathComponent("fridgy_db.json")

        let enc = JSONEncoder()
        enc.outputFormatting = [.prettyPrinted, .sortedKeys]
        enc.dateEncodingStrategy = .iso8601
        self.encoder = enc

        let dec = JSONDecoder()
        dec.dateDecodingStrategy = .iso8601
        self.decoder = dec

        // Load persisted data
        Task { await restoreFromDisk() }
        // Auto-save on changes (debounced to avoid excessive writes)
        observeChangesForAutosave()
    }

    private func observeChangesForAutosave() {
        $items
            .combineLatest($recipes)
            .debounce(for: .seconds(0.5), scheduler: DispatchQueue.main)
            .sink { [weak self] _, _ in
                guard let self, !self.isRestoring else { return }
                self.saveToDisk()
            }
            .store(in: &cancellables)
    }

    private func restoreFromDisk() async {
        isRestoring = true
        defer { isRestoring = false }
        do {
            let db: AppDatabase = try loadDatabase()
            self.items = db.items
            self.recipes = db.recipes
        } catch {
            // First launch or read error; start with empty arrays
        }
    }

    private func saveToDisk() {
        let snapshot = AppDatabase(items: self.items, recipes: self.recipes)
        let url = self.dbURL
        let encoder = self.encoder
        Task.detached(priority: .utility) {
            do {
                let data = try encoder.encode(snapshot)
                try data.write(to: url, options: .atomic)
            } catch {
                // Swallow errors for autosave; consider logging in debug builds.
            }
        }
    }

    // Call to ensure latest state is flushed to disk (e.g., on background)
    func flush() async {
        let snapshot = AppDatabase(items: self.items, recipes: self.recipes)
        do {
            let data = try encoder.encode(snapshot)
            try data.write(to: dbURL, options: .atomic)
        } catch {
            // Consider logging in debug builds
        }
    }

    private func loadDatabase() throws -> AppDatabase {
        let fm = FileManager.default
        guard fm.fileExists(atPath: dbURL.path) else {
            throw CocoaError(.fileNoSuchFile)
        }
        let data = try Data(contentsOf: dbURL)
        return try decoder.decode(AppDatabase.self, from: data)
    }

    // MARK: - Documents directory + images
    private var documentsDirectory: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
    }

    func imageURL(for filename: String) -> URL {
        documentsDirectory.appendingPathComponent(filename)
    }

    func saveImage(_ image: UIImage, prefix: String) -> String? {
        let filename = "\(prefix)_\(UUID().uuidString).jpg"
        let url = imageURL(for: filename)
        guard let data = image.jpegData(compressionQuality: 0.9) else { return nil }
        do {
            try data.write(to: url, options: .atomic)
            return filename
        } catch {
            return nil
        }
    }

    func deleteImage(named filename: String) {
        let url = imageURL(for: filename)
        try? FileManager.default.removeItem(at: url)
    }

    // MARK: - Computed lists
    var expiringSoon: [FridgeItem] {
        items.filter { $0.removedDate == nil && $0.isExpiringSoon }
             .sorted { $0.expiryDate < $1.expiryDate }
    }

    // Newly added: expired items that are still in the fridge (not moved to history)
    var expiredItems: [FridgeItem] {
        items.filter { $0.removedDate == nil && $0.isExpired }
             .sorted { $0.expiryDate < $1.expiryDate }
    }

    var totalItems: [FridgeItem] {
        // Show all non-removed items (including expiring) in All Items
        items.filter { $0.removedDate == nil }
             .sorted { $0.name.lowercased() < $1.name.lowercased() }
    }

    var history: [FridgeItem] {
        items.filter { $0.removedDate != nil }
             .sorted { ($0.removedDate ?? Date.distantPast) > ($1.removedDate ?? Date.distantPast) }
    }

    // Grouping by category for CategoriesView
    var itemsByCategory: [ItemCategory: [FridgeItem]] {
        Dictionary(grouping: items.filter { $0.removedDate == nil }) { $0.category }
    }

    // MARK: - CRUD for items
    func add(_ item: FridgeItem) {
        items.append(item)
        NotificationManager.shared.scheduleNotification(for: item)
        saveToDisk()
    }

    func update(_ item: FridgeItem) {
        guard let idx = items.firstIndex(where: { $0.id == item.id }) else { return }
        items[idx] = item
        NotificationManager.shared.updateNotification(for: item)
        saveToDisk()
    }

    func remove(item: FridgeItem) {
        guard let idx = items.firstIndex(where: { $0.id == item.id }) else { return }
        var copy = items[idx]
        copy.removedDate = Date()
        items[idx] = copy
        NotificationManager.shared.cancelNotification(for: copy)
        saveToDisk()
    }

    func deleteItems(at offsets: IndexSet, from list: [FridgeItem]) {
        // Remove matching ids from items array
        let ids = offsets.map { list[$0].id }
        ids.forEach { id in
            if let i = items.firstIndex(where: { $0.id == id }) {
                if let fn = items[i].imageFilename {
                    deleteImage(named: fn)
                }
                NotificationManager.shared.cancelNotification(for: items[i])
                items.remove(at: i)
            }
        }
        saveToDisk()
    }

    func deleteHistory(at offsets: IndexSet) {
        let ids = offsets.map { history[$0].id }
        ids.forEach { id in
            if let idx = items.firstIndex(where: { $0.id == id }) {
                if let fn = items[idx].imageFilename {
                    deleteImage(named: fn)
                }
                items.remove(at: idx)
            }
        }
        saveToDisk()
    }

    // MARK: - CRUD for recipes
    func addRecipe(_ r: Recipe) {
        recipes.append(r)
        saveToDisk()
    }

    func updateRecipe(_ r: Recipe) {
        guard let idx = recipes.firstIndex(where: { $0.id == r.id }) else { return }
        recipes[idx] = r
        saveToDisk()
    }

    func deleteRecipe(at offsets: IndexSet) {
        for index in offsets {
            if let fn = recipes[index].imageFilename {
                deleteImage(named: fn)
            }
        }
        recipes.remove(atOffsets: offsets)
        saveToDisk()
    }

    // MARK: - Sample data for previews
    static var sample: FridgeStore {
        let s = FridgeStore()
        s.items = [
            FridgeItem(name: "Milk", expiryDate: Calendar.current.date(byAdding: .day, value: 2, to: Date())!, amount: "1L", note: "2% milk", category: .dairy),
            FridgeItem(name: "Lettuce", expiryDate: Calendar.current.date(byAdding: .day, value: 1, to: Date())!, amount: "1 head", note: "For salads", category: .vegetables),
            FridgeItem(name: "Chicken Breast", expiryDate: Calendar.current.date(byAdding: .day, value: 7, to: Date())!, amount: "2 pcs", note: "Frozen", category: .meat)
        ]
        s.recipes = [
            Recipe(title: "Pasta Primavera", ingredients: "Pasta\nTomatoes\nBasil\nParmesan", notes: "Boil and toss")
        ]
        return s
    }
}
