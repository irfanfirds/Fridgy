import Foundation
import SwiftUI

enum RecipeCategory: String, CaseIterable, Codable {
    case breakfast = "Breakfast"
    case lunch = "Lunch"
    case dinner = "Dinner"
    case snacks = "Snacks"
    case dessert = "Dessert"

    var color: Color {
        switch self {
        case .breakfast: return .yellow
        case .lunch: return .green
        case .dinner: return .orange
        case .snacks: return .purple
        case .dessert: return .red
        }
    }

    var icon: String {
        switch self {
        case .breakfast: return "sun.max.fill"
        case .lunch: return "sun.dust.fill"
        case .dinner: return "moon.stars.fill"
        case .snacks: return "heart.fill"
        case .dessert: return "birthday.cake.fill"
        }
    }
}

struct Recipe: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    var title: String
    var ingredients: String
    var notes: String
    var imageFilename: String? = nil
    var category: RecipeCategory = .dinner
}


