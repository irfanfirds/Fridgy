import Foundation

enum Tab: String, CaseIterable {
    case home = "Home"
    case categories = "Items"
    case add = "Add"
    case history = "History"
    case recipes = "Recipes"

    var icon: String {
        switch self {
        case .home: return "house.circle.fill"
        case .categories: return "square.grid.2x2.fill"
        case .add: return "plus.circle.fill"
        case .history: return "clock.arrow.circlepath"
        case .recipes: return "book.closed.fill"
        }
    }
}


