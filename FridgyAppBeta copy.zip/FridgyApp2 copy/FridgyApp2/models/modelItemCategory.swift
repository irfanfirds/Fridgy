import Foundation
import SwiftUI

enum ItemCategory: String, CaseIterable, Codable {
    case dairy = "Dairy"
    case meat = "Meat"
    case vegetables = "Vegetables"
    case fruits = "Fruits"
    case grains = "Grains"
    case other = "Other"

    var color: Color {
        switch self {
        case .dairy: return .blue
        case .meat: return .red
        case .vegetables: return .green
        case .fruits: return .orange
        case .grains: return .yellow
        case .other: return .purple
        }
    }

    var icon: String {
        switch self {
        case .dairy: return "drop.fill"
        case .meat: return "flame.fill"
        case .vegetables: return "leaf.fill"
        case .fruits: return "apple.logo"
        case .grains: return "circle.grid.2x2.fill"
        case .other: return "square.grid.3x3.fill"
        }
    }
}


