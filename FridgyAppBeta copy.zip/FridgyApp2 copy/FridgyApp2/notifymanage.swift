import Foundation
import UserNotifications
import SwiftUI

final class NotificationManager {
    static let shared = NotificationManager()
    private init() {}

    func requestPermission() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { granted, error in
            if let error = error { print("Notification auth error:", error) }
            print("Notifications granted: \(granted)")
        }
    }

    func scheduleNotification(for item: FridgeItem) {
        // Only schedule for items expiring soon
        guard item.isExpiringSoon, item.removedDate == nil else { return }

        let content = UNMutableNotificationContent()
        content.title = "Fridgy — Expiring soon"
        content.body = "\(item.name) expires in \(item.daysUntilExpiry) day(s)."
        content.sound = .default

        var comps = DateComponents()
        comps.hour = 9
        comps.minute = 0
        let trigger = UNCalendarNotificationTrigger(dateMatching: comps, repeats: true)

        let req = UNNotificationRequest(identifier: item.id.uuidString, content: content, trigger: trigger)
        UNUserNotificationCenter.current().add(req) { error in
            if let e = error { print("Failed to schedule notification:", e) }
        }
    }

    func updateNotification(for item: FridgeItem) {
        cancelNotification(for: item)
        scheduleNotification(for: item)
    }

    func cancelNotification(for item: FridgeItem) {
        UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: [item.id.uuidString])
    }
}
