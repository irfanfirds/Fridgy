import SwiftUI

extension Color {
    static let appBlack = Color(hex: "1A1A1A")
    static let appCream = Color(hex: "EDECDF")
    static let appLightGray = Color(hex: "F2F2F2")
    static let appBrown = Color(hex: "A8866C")
    static let appDarkBrown = Color(hex: "8C6658")
    static let appWhite = Color.white
    static let appRed = Color(hex: "FF6B6B")
    static let appOrange = Color(hex: "FF8E53")
    static let appBlue = Color(hex: "4ECDC4")
    static let appGreen = Color(hex: "A8E6CF")
    static let appPurple = Color(hex: "C7CEEA")
    static let appYellow = Color(hex: "FFE66D")

    init(hex: String) {
        let hex = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int: UInt64 = 0
        Scanner(string: hex).scanHexInt64(&int)
        let a, r, g, b: UInt64
        switch hex.count {
        case 3:
            (a, r, g, b) = (255, (int >> 8) * 17,
                             (int >> 4 & 0xF) * 17,
                             (int & 0xF) * 17)
        case 6:
            (a, r, g, b) = (255,
                             int >> 16,
                             int >> 8 & 0xFF,
                             int & 0xFF)
        case 8:
            (a, r, g, b) = (int >> 24,
                             int >> 16 & 0xFF,
                             int >> 8 & 0xFF,
                             int & 0xFF)
        default:
            (a, r, g, b) = (1, 1, 1, 0)
        }

        self.init(
            .sRGB,
            red: Double(r) / 255,
            green: Double(g) / 255,
            blue: Double(b) / 255,
            opacity: Double(a) / 255
        )
    }
}
