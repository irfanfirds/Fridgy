// DashboardCard.swift
import SwiftUI

struct DashboardCard: View {
    // content
    let icon: String
    let title: String
    let subtitle: String
    let count: Int
    // optional navigation destination - wrapped as AnyView to avoid generics ambiguity
    let destination: AnyView?

    init(icon: String,
         title: String,
         subtitle: String = "",
         count: Int = 0,
         destination: AnyView? = nil)
    {
        self.icon = icon
        self.title = title
        self.subtitle = subtitle
        self.count = count
        self.destination = destination
    }

    var body: some View {
        Group {
            if let dest = destination {
                NavigationLink(destination: dest) {
                    content
                }
            } else {
                content
            }
        }
        .frame(maxWidth: .infinity)
    }

    private var content: some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .font(.system(size: 24, weight: .semibold))
                .foregroundColor(.appBrown)
                .frame(width: 40, height: 40)
                .background(
                    LinearGradient(colors: [.appCream, .appLightGray], startPoint: .topLeading, endPoint: .bottomTrailing)
                )
                .clipShape(Circle())

            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.subheadline)
                    .fontWeight(.semibold)
                    .foregroundColor(.appBlack)
                if !subtitle.isEmpty {
                    Text(subtitle)
                        .font(.caption)
                        .foregroundColor(.appDarkBrown.opacity(0.8))
                }
            }

            Spacer()

            Text("\(count)")
                .font(.title3.weight(.bold))
                .foregroundColor(.appBrown)
        }
        .padding(16)
        .background(Color.appWhite)
        .cornerRadius(16)
        .shadow(color: .black.opacity(0.05), radius: 8, x: 0, y: 4)
    }
}

#Preview {
    DashboardCard(icon: "exclamationmark.triangle.fill",
                  title: "Expiring Soon",
                  subtitle: "Within 3 days", count: 3,
                  destination: AnyView(EmptyView()))
        .padding()
        .previewLayout(.sizeThatFits)
}
